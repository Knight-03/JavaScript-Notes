

// let and const ni pan hoisting thay che 
// emne pan Global Execution ma memory made che pn 
//  te uninitialised hoy che mate error aape che 

// Uncaught ReferenceError: 
// firstName is not defined
// console.log(firstName);

// Uncaught ReferenceError: 
// Cannot access 'firstName' before initialization
// before initialization aa temporal dead zone ma re 
console.log(firstName)
let firstName;


console.log(typeof firstName);

// let firstName = "harshit";