
console.log(myFunction);

// function expression 
var myFunction = function(){
    console.log("this is my function");
}
console.log(myFunction);