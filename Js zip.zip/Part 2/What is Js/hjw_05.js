console.log("hello world");
let firstName = "Harshit";
let lastName = "Vashistha";

const myFunction = function() {
    let var1 = "First Variable";
    let var2 = "second Variable";
    console.log(var1);
    console.log(var2);
}