// get and set attributes 
const link = document.querySelector("ul")
console.log(link.firstElementChild);
// link.setAttribute("href","https://codepan.com")
// console.log(link.getAttribute("href"))

// const inputElement = document.querySelector(".form-todo input")
// console.log(inputElement.getAttribute("type"))