// select element using 
// * get element by id 
const mainHeading = document.getElementById("main-heading");
console.log(mainHeading)
// ek object return thay che dekhashe html element pn che js object 