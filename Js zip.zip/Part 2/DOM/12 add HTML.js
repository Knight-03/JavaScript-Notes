// Add new HTML elements to page 


// innerHTML to add html element 

const todoList = document.querySelector(".todo-list")
console.log(todoList.innerHTML);
// todoList.innerHTML = "<li> New Todo </li>";

// todoList.innerHTML += "<li> New Todo </li>";
// todoList.innerHTML += "<li> New Todo </li>";
// console.log(todoList.innerHTML);


// when you should use it, when you should not 

// aa rite add kariye browser pehlana todo ne pn render kare atle time jaay 
