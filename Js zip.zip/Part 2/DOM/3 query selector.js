// select element using query selector

// const mainHeading = document.getElementById("main-heading");
const mainHeading = document.querySelector("#main-heading");
const header = document.querySelector(".header");
const navItem = document.querySelector(".nav-items") // aa ek j item return krse home vadi jen jode aa nav-item vado class aa che 
// aa badhi item apdne nai dekhay 
console.log(navItem)
console.log(header)
console.log(mainHeading);
