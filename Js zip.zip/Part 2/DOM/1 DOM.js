// DOM (Document Object Model) 
// document object model 
// overview 
// how to use 
// deep study
// console.dir(document);
console.dir(document)