// change text 
// textContext and InnerText 

// const mainHeading = document.getElementById("main-heading")
// console.log(mainHeading.textContent) // output will be : Manage your task Hello 
// console.log(mainHeading.innerText) // Manage your task

// mainHeading.textContent = "Chnaged heading";
// console.log(mainHeading.textContent)
