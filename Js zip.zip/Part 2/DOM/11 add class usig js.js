const sectionTodo = document.querySelector(".section-todo");
console.log(sectionTodo.classList)
// sectionTodo.classList.add('bg-dark')
// sectionTodo.classList.remove("container")
// sectionTodo.classList.contains("container");
// sectionTodo.classList.toggle("bg-dark"); //agar class che to remove karse na hoy to add karshe 
// sectionTodo.classList.toggle("bg-dark"); 

const header = document.querySelector(".header");
// header.classList.add("bg-dark");
console.log(header.classList)
