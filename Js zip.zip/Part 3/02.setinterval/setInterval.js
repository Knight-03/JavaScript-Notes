
console.log("script start");

setInterval(() =>{
    console.log(Math.random());
}, 1000); 

for(let i=1;i< 100;i++){
    console.log("...");
}
console.log("script end");