// hoisting 

hello(); // this will give error in 2nd and 3rd type of declaration of function 

// function declration 
function hello(){
    console.log("hello");
}

// function expression 
// var hello = function() { //var laiye let laiye ke const badha ma error apshe cuz of 3rd line 
//     console.log("hello");
// }

//arrow function 
// const hello = () =>{
//     console.log("hello");
// }

