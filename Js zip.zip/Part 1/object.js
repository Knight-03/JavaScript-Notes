// objectes referece typeo
// arrays are good but not sufficient
// for real world data
// objects strore key value pairs
// objects don't have index 

//how to create objects
const person = {
    name : "cam",
    age : "20",
    hobbies : ["singing","time passing"]
}
console.log(person)
console.log(person["name"])
console.log(person.age)
console.log(person.hobbies)

//how to add key value pair to object
person["sex"] = "female" // person.sex = "female"
console.log(person)




