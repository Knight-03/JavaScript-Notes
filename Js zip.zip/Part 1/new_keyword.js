// new keyword
function createUser(firstName,age){
    this.firstName = firstName
    this.age = age
}

createUser.prototype.about = function(){
   return ("I am " + this.firstName + " and I am " + this.age + " years old")
}
const user1 = new createUser("Knight",19)
console.log(user1.about())

// new keyword 
// 1.) empty object create kr ra 
// and aa empty object ni value this che matlab this refere kare che 
// empty obj ne ==> this = {}

// 2.)  return this

// 3.) je kaaam apde mannually kari rya ta 
//  Object.create(createUser.prototype); 
// new keyword __proto__ ni value ne prototype ne equal set kari deshe 
